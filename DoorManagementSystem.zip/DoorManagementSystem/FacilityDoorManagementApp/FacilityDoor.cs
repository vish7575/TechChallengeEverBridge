﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FacilityDoorManagementApp
{
   public class FacilityDoor
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = this.PropertyChanged;
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        private bool isLocked = false;
        public bool IsLocked
        {
            get
            {
                return isLocked;
            }
            set
            {
                isLocked = value;
                IsModified = true;

                OnPropertyChanged("IsLocked");
            }
        }

        private string customLabel = string.Empty;
        public string CustomLabel
        {
            get
            {
                return customLabel;
            }
            set
            {
                customLabel = value;
                IsModified = true;

                OnPropertyChanged("CustomLabel");
            }
        }

        private string name = string.Empty;
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
                IsModified = true;
                OnPropertyChanged("Name");
            }
        }

        private int id ;
        public int ID
        {
            get
            {
                return id;
            }
            set
            {
                id = value;
                OnPropertyChanged("ID");
            }
        }

        private bool isOpen = false;
        public bool IsOpen
        {
            get
            {
                return isOpen;
            }
            set
            {
                isOpen = value;
                IsModified = true;
                OnPropertyChanged("IsOpen");
            }
        }

        private bool isModified = false;
        public bool IsModified
        {
            get
            {
                return isModified;
            }
            set
            {
                isModified = value;
                OnPropertyChanged("IsModified");
            }
        }

        private bool allowEditingName = false;
        public bool AllowEditingDoorName
        {
            get
            {
                return allowEditingName;
            }
            set
            {
                allowEditingName = value;
                //EnableLockUnlock = allowEditingName;
                //EnableOpenClose = allowEditingName;
                //EnableEditCustomlable = allowEditingName;
                OnPropertyChanged("AllowEditingDoorName");
            }
        }

        private bool enableLock_UnLock = false;
        public bool EnableLockUnlock
        {
            get
            {
                return enableLock_UnLock;
            }
            set
            {
                enableLock_UnLock = value;
                OnPropertyChanged("EnableLockUnlock");
            }
        }

        private bool enableopen_Close = false;
        public bool EnableOpenClose
        {
            get
            {
                return enableopen_Close;
            }
            set
            {
                enableopen_Close = value;
                OnPropertyChanged("EnableOpenClose");
            }
        }

        private bool enableEditCustomLable = false;
        public bool EnableEditCustomlable
        {
            get
            {
                return enableEditCustomLable;
            }
            set
            {
                enableEditCustomLable = value;
                OnPropertyChanged("EnableEditCustomlable");
            }
        }
    }
}

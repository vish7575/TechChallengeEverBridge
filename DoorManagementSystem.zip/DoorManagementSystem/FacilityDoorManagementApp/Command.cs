﻿using System;
using System.Windows.Input;
using System.ComponentModel;

namespace FacilityDoorManagementApp
{
    public class Command : ICommand
    {
      //  private readonly Func<bool> _whentoExecute;
        private readonly Action _whattoExecute;

        public Command(Action what)
        {
            _whattoExecute = what;
        }

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            if (this._whattoExecute != null)
            {
                _whattoExecute();
            }
        }

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }
    }
}
